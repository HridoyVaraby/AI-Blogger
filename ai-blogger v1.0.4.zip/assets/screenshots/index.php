<?php // Silence is golden
